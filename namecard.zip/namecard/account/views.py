from django.shortcuts import render
from .models import *

# Create your views here.

def home(request):
    return render(request,'home.html')

def namecard(request):
    user_id = request.GET['user_id']
    # user_id = 'BFZ78FAEBFV6R44Z'
    Data = Account.objects.get(Key=user_id)
    IP_Address = request.META.get('REMOTE_ADDR')
    Device = request.META.get('HTTP_USER_AGENT')
    count = Counter.objects.create(Account=Data,IP_Address=IP_Address,Device=Device)
    count.save()

    return render(request,'namecard.html',{'Data':Data})

def dooduange(request):
    Data = 'Hello World'
    return render(request,'dooduange.html',{'Data':Data})
