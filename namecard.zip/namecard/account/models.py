from django.db import models

# Create your models here.

from django.db import models
import random
import string

def generate_reference_id():
    characters = string.ascii_uppercase + string.digits
    reference_id = ''.join(random.choice(characters) for _ in range(16))
    return reference_id

class Account(models.Model):
    Key = models.CharField(max_length=16, default=generate_reference_id)
    
    Name_TH = models.CharField(max_length=200, default="")
    Name_EN = models.CharField(max_length=200, default="")
    Position_TH = models.CharField(max_length=200, default="")
    Position_EN = models.CharField(max_length=200, default="")
    Address_TH = models.TextField(max_length=200, default="")
    Address_EN = models.TextField(max_length=200, default="")
    Other = models.TextField(max_length=200, default="") 

    Email = models.CharField(max_length=200, default="")
    Telephone = models.CharField(max_length=50, default="")
    Line = models.CharField(max_length=50, default="")

    def __str__(self):
        return "{} : {}".format(str(self.Name_EN),self.Telephone)

class Counter(models.Model):
    TimeStamp = models.DateTimeField(auto_now_add=True)
    Account = models.ForeignKey(Account, on_delete=models.CASCADE)
    
    IP_Address = models.GenericIPAddressField(default="1.1.1.1")
    Device = models.CharField(max_length=100,default="-")

    def __str__(self):
        return "{} : {} {}".format(self.TimeStamp,self.Account.Key,self.Account.Name_EN)

